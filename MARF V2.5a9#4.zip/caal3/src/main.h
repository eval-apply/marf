#include "HC165.h"

unsigned char keyb_proc(uButtons * key);
void mADC_init(void);
void ADCPause(void);

void delay_ms(unsigned int ms);
void delay_us(unsigned int us);

